
public interface Logavel {
	
	public Boolean logar(String usuario, String senha);
	
	public String getUsername();
	
	public Permissoes getPermissoes();
}
