public enum Permissoes {
    COMUM,
    ADMIN
}
